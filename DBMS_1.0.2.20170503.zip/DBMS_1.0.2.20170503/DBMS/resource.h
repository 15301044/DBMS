//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� DBMS.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_DBMSTYPE                    130
#define IDM_OPEN_DATABASE               32771
#define IDM_NEW_TABLE                   32772
#define IDM_CREATE_DATABASE             32773
#define ID_DATABASE_OPENDATABASE        32774
#define IDM_MODIFY_TABLE                32775
#define IDM_DELETE_TABLE                32776
#define ID_FIELD_ADDFIELD               32777
#define IDM_ADD_FILED                   32778
#define IDM_MODIFY_FIELD                32779
#define IDM_DELETE_FIELD                32780
#define IDM_ADD_RECORD                  32781
#define IDM_OPEN_TABLE                  32782
#define ID_Menu                         32783
#define IDM_MODIFY_RECORD               32784
#define IDM_DELETE_RECORD               32785
#define ID_CREATE_DATABASE              32786
#define ID_OPEN_DATABASE                32787
#define ID_NEW_TABLE                    32788
#define ID_ALTER_TABLE                  32789
#define ID_DROP_TABLE                   32790
#define ID_CREATE_TABLE                 32791
#define ID_ADD_FILED                    32792
#define ID_MODIFY_FILED                 32793
#define ID_DROP_FILED                   32794
#define ID_CREATE_TABLIDM_NEW_TABLEE    32795
#define IDM_CREATE_TABLE                32796
#define IDM_ALTER_TABLE                 32797
#define IDM_DROP_TABLE                  32798
#define IDM_ADD_FIELD                   32799
#define IDM_DROP_FIELD                  32800
#define IDM_INSERT_RECORD               32801
#define IDM_SELECT_RECORD               32802
#define IDM_UPDATE_RECORD               32803

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32804
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
